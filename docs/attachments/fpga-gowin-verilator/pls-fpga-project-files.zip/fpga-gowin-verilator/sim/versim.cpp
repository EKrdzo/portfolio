#include <stdlib.h>
#include <iostream>
#include <verilated.h>
#include <verilated_fst_c.h>
#include "Vproject.h"   // ime mora odgovarati imenu modula

vluint64_t sim_time = 0;
double sc_time_stamp() { return sim_time; }

int main(int argc, char** argv, char** env) {
    Vproject *dut = new Vproject;

    Verilated::traceEverOn(true);
    VerilatedFstC *m_trace = new VerilatedFstC;

    dut->trace(m_trace, 5);
    m_trace->open("waveform.fst");

	int testna_sekvenca [] = {0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1};
	int br = sizeof(testna_sekvenca) / sizeof(testna_sekvenca[0]);

	dut->U = 0;
	dut->Cp = 1;
	dut->reset = 0;       
    dut->eval();
    m_trace->dump(sim_time++);

	for(int i = 0; i<br ; i++){
		
		dut->U = testna_sekvenca[i];
		dut->Cp = 0;
		dut->eval();
        m_trace->dump(sim_time++);

		if(i == 12)
			dut->reset = 1;
		dut->Cp = 1;        
        dut->eval();
        m_trace->dump(sim_time++);
		if(i == 12)
			dut->reset = 0;
	}

    m_trace->close();
    delete dut;
    return 0;
}

