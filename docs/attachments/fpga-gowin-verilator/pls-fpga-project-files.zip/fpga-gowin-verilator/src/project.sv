module project (
    input  logic U,
    input  logic Cp,
    input  logic reset,
    output logic C0,
    output logic C1,
    output logic C2,
    output logic C3,
    // output logic slow_clk,
    output logic Z
);
    logic Q0, Q1;
    logic T0, T1;

    logic [24:0] cnt;
    logic slow_clk;
    
    always_ff @(posedge Cp or posedge reset) begin
        if (reset) begin
            cnt      <= 0;
            slow_clk <= 0;
        end
        else if (cnt >= 25'd13_500_000) begin // ≈1 Hz
            cnt      <= 0;
            slow_clk <= ~slow_clk;
        end
        else begin
            cnt <= cnt + 1;
        end
    end

    always_ff @(posedge slow_clk or posedge reset) begin
        if (reset) begin
            Q0 <= 1'b0;
            Q1 <= 1'b0;
        end else if (slow_clk) begin
            if (T0) Q0 <= ~Q0;  
            if (T1) Q1 <= ~Q1;
        end
    end

    always_comb begin
        Z  = ~U & Q0 & Q1;
        T0 = (U & ~Q1) | Q1 & (~U | ~Q0);
        T1 = (~U & Q1) | (U & Q0 & ~Q1);

        C0 = ~Q1 & ~Q0;
        C1 = ~Q1 & Q0;
        C2 = Q1 & ~Q0;
        C3 = Q1 & Q0;
    end

endmodule : project