// IMPORTANT: This is simulation only code.
module project (
    input  logic U,
    input  logic Cp,
    input  logic reset,
    output logic Z
);
    logic Q0, Q1;
    logic T0, T1;

    always_ff @(posedge Cp or posedge reset) begin
        if (reset) begin
            Q0 <= 1'b0;
            Q1 <= 1'b0;
        end else begin
            if (T0) Q0 <= ~Q0;
            if (T1) Q1 <= ~Q1;
        end
    end

    always_comb begin
        Z  = ~U & Q0 & Q1;
        T0 = (U & ~Q1) | Q1 & (~U | ~Q0);
        T1 = (~U & Q1) | (U & Q0 & ~Q1);
    end

endmodule : project