module Lab4 (
    input  logic reset,
    input  logic Cp,        // 27 MHz
    input  logic ulaz,
    output logic y
);

logic [1:0] stanje, sljedece_stanje;

logic [24:0] cnt;
logic slow_clk;

always_ff @(posedge Cp or posedge reset) begin
    if (reset) begin
        cnt      <= 0;
        slow_clk <= 0;
    end
    else if (cnt == 25'd13_500_000) begin // ≈1 Hz
        cnt      <= 0;
        slow_clk <= ~slow_clk;
    end
    else begin
        cnt <= cnt + 1;
    end
end

always_ff @(posedge Cp or posedge reset) begin
    if (reset)
        stanje <= 2'd0;
    else
        stanje <= sljedece_stanje;
end
always_comb begin
    // default vrijednosti (VAŽNO!)
    y = 1'b0;
    sljedece_stanje = stanje;

    case (stanje)
        2'd0: begin
            if (ulaz) begin
                y = 1'b1;
                sljedece_stanje = 2'd2;
            end else begin
                y = 1'b0;
                sljedece_stanje = 2'd0;
            end
        end

        2'd1: begin
            if (ulaz) begin
                y = 1'b1;
                sljedece_stanje = 2'd2;
            end else begin
                y = 1'b0;
                sljedece_stanje = 2'd3;
            end
        end

        2'd2: begin
            if (ulaz) begin
                y = 1'b0;
                sljedece_stanje = 2'd2;
            end else begin
                y = 1'b1;
                sljedece_stanje = 2'd1;
            end
        end

        2'd3: begin
           if (ulaz) begin
                y=1'b1;
                sljedece_stanje=2'd0;
            end else begin
                y=1'b0;
                sljedece_stanje=2'd0;
            end
        end
    endcase
end


endmodule