Kp=0.00016606;
Ki=0.29602;
%% MATLAB Skripta za analizu male promjene faktora ispune (D) kod Boost pretvarača
% Analiza upravljačke prenosne funkcije Gvd(s)
clear; clc; close all;

%% 1. Definisanje nominalnih parametara Boost pretvarača
% Zamijeni ove vrijednosti stvarnim parametrima tvog hardvera/baterije
Vin = 24;          % Ulazni napon [V]
Vout = 54.6;         % Željeni izlazni napon [V]
D = 1 - (Vin/Vout); % Nominalni faktor ispune (Duty cycle) v_out = v_in / (1-D)

L = 0.59e-3;        % Induktivitet prigušnice [H]
C = 1.4e-3;        % Kapacitet izlaznog kondenzatora [F]
R = 10.92;            % Ekvivalentni otpor opterećenja [Ohm] (kod baterije unijeti dinamički otpor)

%% 2. Proračun parametara standardne forme prenosne funkcije
% DC pojačanje (Gain)
Gd0 = Vout / (1 - D); 

% Rezonantna frekvencija (uglovna frekvencija polova LC filtra)
omega_0 = (1 - D) / sqrt(L * C); 
f_0 = omega_0 / (2 * pi);

% Faktor dobrote (Quality Factor)
Q = R * (1 - D) * sqrt(C / L);

% Uglovna frekvencija nule u desnoj poluravni (RHP Zero)
omega_z = (1 - D)^2 * R / L;
f_z = omega_z / (2 * pi);

%% 3. Kreiranje prenosne funkcije u MATLAB-u (s-domena)
s = tf('s');

% Brojilac: (1 - s/omega_z) -> RHP nula unosi minus ispred s člana!
brojilac = 1 - (s / omega_z);

% Imenilac: (1 + s/(Q*omega_0) + (s/omega_0)^2)
imenilac = 1 + (s / (Q * omega_0)) + (s / omega_0)^2;

% Ukupna prenosna funkcija Gvd(s)
Gvd = Gd0 * (brojilac / imenilac);

%% 4. Prikazivanje proračunatih vrijednosti u Command Window
fprintf('--- Parametri modela malog signala Boost pretvarača ---\n');
fprintf('DC Pojačanje (Gd0): %.2f V\n', Gd0);
fprintf('Rezonantna frekvencija (f0): %.2f Hz\n', f_0);
fprintf('Faktor dobrote (Q): %.2f\n', Q);
fprintf('Frekvencija RHP nule (fz): %.2f Hz\n', f_z);
fprintf('-----------------------------------------------------\n');

%% 5. Iscrtavanje Bodeovog dijagrama
figure('Name', 'Bodeov Dijagram Gvd(s)', 'Position', [100, 100, 800, 600]);
options = bodeoptions;
options.FreqUnits = 'Hz'; % Prikaz u Hz umjesto rad/s radi lakše intuicije
options.Grid = 'on';
bode(Gvd, options);
title('Bodeov Dijagram upravljačke funkcije $G_{vd}(s)$ (Duty-to-Output)', 'Interpreter', 'latex');

%% 6. Simulacija odziva na step promjenu D (Pobuda promjene D faktora)
% Pretpostavimo malu step promjenu duty cycle-a: delta_D = 0.05 (npr. skok sa 0.50 na 0.55)
delta_D = 0.05; 
t = linspace(0, 0.015, 2000); % Vremenska osa (0 do 15 milisekundi)

[y, t_out] = step(delta_D * Gvd, t);

figure('Name', 'Odziv na step promjenu faktora ispune (D)', 'Position', [200, 100, 800, 500]);
plot(t_out * 1000, y, 'LineWidth', 2, 'Color', [0 0.4470 0.7410]);
hold on;
% Označavanje nominalnog nivoa stabilnog stanja
line([0 t(end)*1000], [delta_D*Gd0 delta_D*Gd0], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1.5);

grid on;
title(sprintf('Odziv izlaznog napona na promjenu $\\Delta D = %.2f$', delta_D), 'Interpreter', 'latex');
xlabel('Vrijeme [ms]');
ylabel('Promjena izlaznog napona \hat{v}(t) [V]');
legend('Dinamički odziv pretvarača', 'Teoretska nova stacionarna vrijednost', 'Location', 'SouthEast');

% Prozor unutar grafika (Zoom) koji jasno prikazuje podbačaj uslijed RHP nule
axes('Position', [0.55 0.25 0.3 0.3]);
plot(t_out(t_out < 0.001)*1000, y(t_out < 0.001), 'LineWidth', 2, 'Color', [0 0.4470 0.7410]);
grid on;
title('Podbačaj uslijed RHP nule');
xlabel('Vrijeme [ms]');
ylabel('\hat{v} [V]');