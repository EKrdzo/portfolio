%% MATLAB Skripta za analizu i dizajn PI kontrolera Boost pretvarača
%% 1. KORAK: Definisanje hardvera i matematičkog modela 
clear; clc; close all;

% Parametri 
Vin = 24;          % Ulazni napon [V]
Vout = 54.6;         % Željeni izlazni napon [V]
L = 0.59e-3;        % Induktivitet prigušnice [H]
C = 1.4e-3;        % Kapacitet izlaznog kondenzatora [F]
R = 10.92;            % Ekvivalentni otpor opterećenja [Ohm] (kod baterije unijeti dinamički otpor)
fsw = 20e3;         % Frekvencija prekidanja [Hz]

% 1. Izračunavanje faktora ispune (Duty Cycle - D)
% Formula za Boost: Vout = Vin / (1-D)
D = 1 - (Vin/Vout); 

%% 2. KORAK: Analiza dinamičkih karakteristika pretvarača
% Dvije najvažnije frekvencije

% 2.1. Rezonantna frekvencija - f0 
% Predstavlja frekvenciju na kojoj sistem prirodno osciluje
% Svaki sistem koji ima zavojnicu (L) i kondenzator (C) ima tendenciju da osciluje
% Faktor (1-D) je specifičan za Boost jer su L i C povezani samo dok tranzistor ne vodi
omega_0 = (1 - D) / sqrt(L * C); 
f_0 = omega_0 / (2 * pi); 

% 2.2. Nula u desnoj poluravni - fz
% Ovo je kritična tačka Boosta - uzrokuje fazno kašnjenje od 90 stepeni uz rast pojačanja
% Zbog nje je nemoguće postići jako brz odziv sistema a da on ostane stabilan
omega_z = ((1 - D)^2 * R) / L;
f_z = omega_z / (2 * pi); 

fprintf('--- Dinamička analiza ---\n');
fprintf('Rezonantna frekvencija (f0): %.2f Hz\n', f_0);
fprintf('RHP nula (fz): %.2f Hz\n', f_z);
fprintf('Maksimalna dozvoljena brzina regulatora (fz/5): %.2f Hz\n', f_z/5);

%% 3. KORAK: Kreiranje matematičkog modela 
s = tf('s'); % Definisanje kompleksne varijable 's'

% DC pojačanje - koliko puta pretvarač prirodno pojačava ulazni signal
Gd0 = Vin / (1 - D)^2; 

% Faktor dobrote - Q 
Q = R * (1 - D) * sqrt(C / L);

% Formiranje prenosne funkcije Gvd(s) - od faktora ispune do izlaznog napona
% Ova formula spaja sve: DC gain, RHP nulu i LC polove (rezonanciju)
Gvd = Gd0 * ( (1 - s/omega_z) / (1 + s/(Q*omega_0) + (s/omega_0)^2) );

% Uključivanje PWM modulatora 
Vm = 1; 
G_plant = Gvd / Vm; 

% CRTANJE BODE dijagrama samog pretvarača (bez ikakvog regulatora)
bode(G_plant);
grid on;
title('Bodeov dijagram Boost pretvarača (bez regulatora)');

%% 4. KORAK: DIZAJN PI REGULATORA
% 1. Ciljamo jako malu brzinu (npr. 20 Hz) da preskočimo sve probleme
fc_safe = 10; 
omega_c_safe = 2 * pi * fc_safe;

% 2. Očitavamo pojačanje samog pretvarača na toj frekvenciji
[mag, ~] = bode(G_plant, omega_c_safe);

% 3. Računamo Kp tako da u toj tački pojačanje bude 1 (0 dB)
% Dodajemo faktor 0.5 radi dodatne sigurnosti
Kp = 0.5 / mag; 

% 4. Postavljamo Ti tako da regulator "smiri" sistem
% Neka integralno pojačanje krene ranije
Ti = 1 / (2 * pi * (fc_safe / 2)); 
Ki = Kp / Ti;

% ISPIS NOVIH PARAMETARA
fprintf('\n--- RUČNO PODEŠENI PARAMETRI ---\n');
fprintf('Kp (Gain): %.5f\n', Kp);
fprintf('Ki: %.5f\n', Ki);
fprintf('Ti (Time Constant): %.5f s\n', Ti);

%% 5. PROVJERA
T_final = G_plant * (Kp + Ki/s);
ClosedLoop_final = feedback(T_final, 1);

figure('Name', 'Bode');
margin(T_final); 
grid on;

figure('Name', 'Odziv');
t_sim = linspace(0, 0.5, 5000); % 200 ms da vidimo smirenje
step(1 * ClosedLoop_final, t_sim);
grid on;
title('Odziv na skok od 1V');