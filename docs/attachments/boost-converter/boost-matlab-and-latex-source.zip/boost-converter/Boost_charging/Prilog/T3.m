%% MATLAB Skripta za dizajn STRUJNOG PI regulatora (CC Faza)
clear; clc; close all;

% Parametri 
Vin = 24;            % Ulaznih 24 V
Vout_start = 39;     % Pocetni napon baterije (praza)
Vout_end = 54.6;     % Kraj CC faze
L = 0.59e-3;         
C = 1.4e-3;          
I_punjenja = 5;      % Zelimo da punimo sa 5 A
fsw = 20e3;          

% Proracunavamo parametre za najgori slucaj (kraj CC faze, 54.6 V)
Vout = Vout_end;
R = Vout / I_punjenja; % Ekvivalentni otpor baterije u CC fazi

% Duty cycle na kraju punjenja
D = 1 - (Vin/Vout); 

%% 1. KORAK: Model struje prigušnice Gid(s)
% Za razliku od Gvd(s), strujna petlja kod Boosta NEMA RHP nulu.
% Gid(s) = (Vout/R) * (2*s*C + 1/R) / (s^2*L*C + s*L/R + (1-D)^2)
s = tf('s');
Gid_num = (Vout / R) * (2*s*C + 1/R);
Gid_den = s^2*L*C + s*L/R + (1-D)^2;
Gid = Gid_num / Gid_den;

figure('Name', 'Bode strujne petlje');
bode(Gid); grid on;
title('Bodeov dijagram strujne petlje Boosta (Gid)');

%% 2. KORAK: Dizajn STRUJNOG PI regulatora
% Strujna petlja može biti mnogo brža od naponske.
% Shannon-Nyquist limit je fsw/10 = 2 kHz. Idemo sigurno na 1/25, fc = 800 Hz.
fc_struja = 800; 
omega_c_struja = 2 * pi * fc_struja;

% Ocitavamo pojacanje strujne petlje na fc
[mag_str, ~] = bode(Gid, omega_c_struja);

% Računamo Kp i Ki. Ovde koristimo jednostavnu metodu jer je Gid stabilna.
Kp_cc = 1 / mag_str; 
Ki_cc = omega_c_struja * 0.1 * Kp_cc; % Postavljamo integralni deo da deluje nize

fprintf('\n--- PARAMETRI STRUJNOG KONTROLERA (CC) ---\n');
fprintf('Kp_cc: %.5f\n', Kp_cc);
fprintf('Ki_cc: %.5f\n', Ki_cc);

%% 3. PROVJERA STRUJNOG ODZIVA
% Otvorena petlja (Regulator * Proces)
T_cc_final = (Kp_cc + Ki_cc/s) * Gid;

% Zatvorena petlja
ClosedLoop_cc_final = feedback(T_cc_final, 1);

figure('Name', 'Bode otvorene petlje');
margin(T_cc_final); grid on;

% Prikaz odziva na skok struje od 1A (npr. sa 4A na 5A)
figure('Name', 'Odziv struje na skok od 1A');
t_sim = linspace(0, 0.05, 5000); % Kraca simulacija jer je brza petlja
step(1 * ClosedLoop_cc_final, t_sim);
grid on;
title('Odziv struje punjenja na skok od 1A');
ylabel('Struja (A)');