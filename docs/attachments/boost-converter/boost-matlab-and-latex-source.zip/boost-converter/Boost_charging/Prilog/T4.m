Kp=0.43728;
Ki=154.9617;

%% 1. Hardverski parametri Boost pretvarača
Vin = 24;           % Ulazni napon [V]
Vout = 54.6;        % Željeni izlazni napon [V]
D = 0.56;           % Faktor ispune (Duty cycle) u radnoj tački

% Komponente LC filtra i opterećenje
L = 0.59e-3;        % Induktivitet prigušnice [H]
C = 1.4e-3;        % Kapacitet izlaznog kondenzatora [F]
R = 10.92;            % Ekvivalentni otpor opterećenja [Ohm] (kod baterije unijeti dinamički otpor)

%% 2. Proračun parametara standardne forme (Imenilac)
% Komplementarni faktor ispune D'
D_prim = 1 - D;

% Rezonantna uglovna frekvencija polova LC filtra
omega_0 = D_prim / sqrt(L * C); 
f_0 = omega_0 / (2 * pi);

% Faktor dobrote (Quality Factor)
Q = R * D_prim * sqrt(C / L);

%% 3. Proračun parametara specifičnih za STRUJNU petlju (Gid)
% DC pojačanje za strujnu prenosnu funkciju (iz Ericksonove matrice)
Gi0 = Vout / (D_prim^2 * R); 

% Uglovna frekvencija nule u LIJEVOJ poluravni (LHP Zero)
% Primijeti: strujna petlja ima stabilnu nulu, nema opasnog minusa!
omega_zi = 2 / (R * C);
f_z_struje = omega_zi / (2 * pi);

%% 4. Kreiranje strujne prenosne funkcije Gid(s) u s-domeni
s = tf('s');

% Brojilac: (1 + s/omega_zi) -> LHP nula unosi PLUS ispred s člana
brojilac_struje = 1 + (s / omega_zi);

% Imenilac: (1 + s/(Q*omega_0) + (s/omega_0)^2) -> Isti je kao za napon
imenilac_struje = 1 + (s / (Q * omega_0)) + (s / omega_0)^2;

% Ukupna prenosna funkcija Gid(s) = i_prigusnice(s) / d(s)
Gid = Gi0 * (brojilac_struje / imenilac_struje);

%% 5. Prikaz i pokretanje alata za podešavanje PI regulatora
fprintf('--- Parametri strujne petlje Boost pretvarača ---\n');
fprintf('Strujno DC pojačanje (Gi0): %.2f A\n', Gi0);
fprintf('Rezonantna frekvencija (f0): %.2f Hz\n', f_0);
fprintf('Stabilna nula strujne petlje (fz_struje): %.2f Hz\n', f_z_struje);
fprintf('-------------------------------------------------\n');

