﻿<?xml version='1.0' encoding='UTF-8'?>
<Project Type="Project" LVVersion="13008000">
	<Item Name="My Computer" Type="My Computer">
		<Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.tcp.enabled" Type="Bool">false</Property>
		<Property Name="server.tcp.port" Type="Int">0</Property>
		<Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
		<Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="InputLV5.vi" Type="VI" URL="../InputLV5.vi"/>
		<Item Name="Zad4.vi" Type="VI" URL="../Zad4.vi"/>
		<Item Name="Dependencies" Type="Dependencies">
			<Item Name="AIn.VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/AIn.VI"/>
			<Item Name="AOut.VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/AOut.VI"/>
			<Item Name="FromEng(array).VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/FromEng(array).VI"/>
			<Item Name="FromEng(single).VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/FromEng(single).VI"/>
			<Item Name="FromEng(trigger).VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/FromEng(trigger).VI"/>
			<Item Name="FromEng.VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/FromEng.VI"/>
			<Item Name="ToEng(array).vi" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/ToEng(array).vi"/>
			<Item Name="ToEng(single).VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/ToEng(single).VI"/>
			<Item Name="ToEng.VI" Type="VI" URL="/&lt;menus&gt;/Universal Library/Das16.llb/ToEng.VI"/>
		</Item>
		<Item Name="Build Specifications" Type="Build"/>
	</Item>
</Project>
