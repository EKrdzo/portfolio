T=31:142;

p1=-0.0959;
p2=16.217;

V_lin=p1*T+p2;

p11=-7/222;
p22=1105/222;
V4=p11*T+p22;

p=V4./V_lin;


a=-0.0001;
b = 0.049 ;
c=0.3112 ;
d =-0.0008;
pp= a*exp(b*T) + c*exp(d*T);

Vo=pp.*V_lin;
plot(T,Vo);

