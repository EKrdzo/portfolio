%Temperaturni opseg na kojem smo mjerili 31-142 °C
T=31:142;


%Po ulzaznoj temperaturi mjeren otpor u kOhm
R_uzl=[11.16, 10.75, 10.4, 10.07, 9.67, 9.3, 8.97, 8.6, 8.4, 8.03, 7.71, 7.5,...
    7.24, 6.9, 6.63, 6.42, 6.16, 5.98, 5.74, 5.62, 5.38, 5.18, 5.05, ...
    4.86, 4.69, 4.5, 4.41, 4.24, 4.12, 3.96, 3.85, 3.72, 3.6, 3.51,...
    3.37, 3.24, 3.14, 3.06, 2.96, 2.87, 2.81, 2.71, 2.65, 2.6, 2.5,...
    2.44, 2.34, 2.26, 2.22, 2.14, 2.08, 2.01, 1.96, 1.9, 1.83, 1.78,...
    1.74, 1.69, 1.64, 1.6, 1.55, 1.52, 1.5, 1.43, 1.39, 1.35, 1.33,...
    1.28, 1.25, 1.21, 1.19, 1.17, 1.13, 1.11, 1.07, 1.05, 1.02, 1,...
    0.98, 0.95, 0.93, 0.9, 0.88, 0.85, 0.83, 0.81, 0.79, 0.77, 0.75,...
    0.74, 0.72, 0.7, 0.68, 0.66, 0.65, 0.64, 0.62, 0.6, 0.59, 0.58,...
    0.57, 0.56, 0.54, 0.52, 0.51, 0.51, 0.5, 0.48, 0.47, 0.46, 0.45, 0.44];

%Po silaznoj temperaturi mjeren otpor u kOhm
R_sil=[10.97,10.43, 9.98, 9.52, 9.15, 8.72, 8.35, 8.15, 7.96, 7.72, 7.23, 7.04,...
    6.92, 6.45, 6.37, 6.13, 5.85, 5.75, 5.53, 5.37, 5.15, 4.97, 4.8,...
    4.68, 4.54, 4.41, 4.23, 4.12, 3.95, 3.75, 3.63, 3.54, 3.43, 3.32,...
    3.19, 3.1, 2.96, 2.9, 2.82, 2.74, 2.66, 2.57, 2.5, 2.42, 2.33,...
    2.28, 2.23, 2.16, 2.08, 2.01, 1.94, 1.89, 1.82, 1.78, 1.72, 1.67,...
    1.63, 1.58, 1.54, 1.48, 1.45, 1.42, 1.38, 1.33,1.3, 1.27, 1.24, 1.19,...
    1.17, 1.14, 1.1, 1.08, 1.05, 1.03, 1, 0.98, 0.95, 0.93, 0.91, 0.89,...
    0.86, 0.84, 0.82, 0.8, 0.79, 0.77, 0.74, 0.73, 0.72, 0.69, 0.68, 0.66,...
    0.64, 0.62, 0.61, 0.6, 0.58, 0.57, 0.55, 0.54, 0.53, 0.52, 0.51, 0.49,...
    0.48, 0.48, 0.47, 0.45, 0.44, 0.42, 0.42, 0.4];

%Usrednjena vrijednost izmjerenog otpora
R=(R_uzl + R_sil)/2;

%Crtamo sve ove otpore kao R=f(T)
figure;
hold on;
grid on;
plot(T,R_uzl, '--','LineWidth',1.5);
plot(T,R_sil, '--','LineWidth',1.5);
plot(T,R,'LineWidth',1.5);
xlabel("Temperatura [°C]");
ylabel("Otpor [kOhm]");
legend("R_{uzl}","R_{sil}","R");
title("Ovisnost otpora o temperaturi");

figure;
hold on;
grid on;
plot(R,T,'LineWidth',1.5);
xlabel("Otpor [kOhm]");
ylabel("Temperatura [°C]");
legend("R");
title("Ovisnost temperature o otporu");

%Senzorski dio U=f(R), R=f(T), gdje U moze imati bilo koju vrijedost

%U=f(T)
R1=1.6; %Odabrano 
V=15;  %Proracunato 
V_NTC = V * (R ./ (R + R1));

%Ovisnost   temperature o V_NTC




p1=-0.0806;
p2=2.1028;
p3=-27.286;
p4=209.26;
%f(x) = p1*x^3 + p2*x^2 + p3*x + p4

%Linearna aproksimacija funckije V_NTC za 31-120 stepeni
p1=-0.1003;
p2o=16.5044;
V_lin=p1*T+p2o;

%Njen inverz
%inverzna Tn=(V_lin-p2)/p1; 
%Znači ovdje je gotov senzorski dio, imamo ovisnost temperature od
%izmjerenog napona
p1n=-9.9701;
p2n=164.5503;
Tn=p1n*V_lin+p2n;

%Crtamo ove prave
figure;
hold on;
grid on;
plot(T,V_NTC,'LineWidth',1.5);
plot(T,V_lin,'LineWidth',1.5);
xlabel("Temperatura [°C]");
ylabel("Napon [V]");
legend("V_{NTC}","V_{lin}");
%legend("V_{NTC}");
title("Temperaturno-naponska karakteristika");

%Crtamo inverznu, dalje je koristimo
figure;
hold on;
grid on;

plot(V_NTC,T, '--','LineWidth',1.5);
plot(V_lin,Tn,'LineWidth',1.5);
xlabel("Napon [V]");
ylabel("Temperatura [°C]");
legend("V_{NTC}","V_{lin}");

title("Temperatura ovisna o naponu");

%Transdjuserski dio, sada moramo svesti ovaj napon na napon izmedju 0.5 i
%4V
%Prava koju zelimo da dobijemo ima oblik:
k=-3.5/89;
n=5.2192;
pp=k*T+n;
%figure;
%plot(T,pp);

%kriva koja će pretvoriti opseg
%p=pp./V_lin;

a=-0.0002;
b=0.0533;
c=0.3383;
d=-0.0035;
p = a*exp(b*T) + c*exp(d*T);

%I izlazna funkcija i njen inverz koji nam govori ovisnost temperature od
%generiranog napona
%Vo=p.*V_lin;
p1o=-0.0399;
p2o=5.2415;
Vo=(p1o*T+p2o)+(0.0399*T-4.7414).*heaviside(T-120);

p1oi=-25.0640;
p2oi=131.390;
To=(p1oi*Vo+p2oi).*heaviside(Vo-0.5);

figure;
hold on;
grid on;
plot(T,Vo,'LineWidth',1.5);
xlabel("Temperatura [°C]");
ylabel("Napon [V]");

title("Izlazni napon ovisan o temperaturi");

%-0.0806*((V_NTC-1.925)/3.119)**3+2.1028*((V_NTC-1.925)/3.119)**2-27.2858*((V_NTC-1.925)/3.119)+209.2563 