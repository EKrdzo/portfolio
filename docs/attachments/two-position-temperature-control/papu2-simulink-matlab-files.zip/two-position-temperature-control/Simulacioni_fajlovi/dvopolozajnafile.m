Rn=((1.64)./(10-izlaz)).*izlaz;
T=76.716 *exp(-1.6759*Rn) + 79.481 *exp(-0.194*Rn);

figure;
hold on;
grid on;
plot(t,T,'LineWidth',1.5);