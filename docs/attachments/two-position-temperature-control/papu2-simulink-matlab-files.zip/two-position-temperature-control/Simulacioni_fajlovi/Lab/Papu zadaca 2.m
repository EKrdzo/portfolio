figure
plot(out.t, out.izlaz,'LineWidth',2);
xlabel('Vrijeme(s)');
ylabel('Odziv');
grid on;