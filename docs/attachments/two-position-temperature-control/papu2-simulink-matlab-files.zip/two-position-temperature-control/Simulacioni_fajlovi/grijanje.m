
Rn=((1.64)./(15-izlaz)).*izlaz;
T=76.716 *exp(-1.6759*Rn) + 79.481 *exp(-0.194*Rn);

u1=1;
while(pobuda(u1)==0)
    u1=u1+1;
end;

temp=0;
for(j=1:1:u1)
    temp=temp+T(j);
end
SSS=temp/j;

temp=0;
for(j=length(T)-200:1:length(T))
    temp=temp+T(j);
end
NSS=temp/200;
figure;
grid on;
hold on;
plot(t,T,'LineWidth',1.5);
v1=NSS-SSS;
x=(v1*0.63)+SSS;
ta=44.895*exp(0.0211*x) + 0*exp( 0.2529*x);
tau=ta-135;
t1=0:0.5:135;
y1=SSS*ones(1,271);
plot(t1,y1,'LineWidth',1.5);
u=220.*pobuda;
plot(t,u,'LineWidth',1.5);
s = tf('s');
K = v1 / 220;          % make sure v1 is defined beforehand
G = tf([K], [tau, 1]); % transfer function

tn = linspace(0, 672, 672*2);  % time vector
[y, t_out] = step(G * 220, tn); % scale step input by 220, get response

plot(t_out, y);
t_shifted = t_out + 135;            % Shift time right by 135s
y_shifted = y + 46.8771;            % Shift output up by 46.8771

plot(t_shifted, y_shifted);