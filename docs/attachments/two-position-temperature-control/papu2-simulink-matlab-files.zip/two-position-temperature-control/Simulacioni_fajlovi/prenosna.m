Rn=((1.64)./(10-izlaz)).*izlaz;
T=76.716 *exp(-1.6759*Rn) + 79.481 *exp(-0.194*Rn);

ss1=32.4753;
SS1=32.4753*ones(1,108*2);
t1=linspace(1,108,108*2);

ss2=93.7769;
SS2=93.7769*ones(1,36*2);
t2=linspace(771.5,807.5,36*2);

ss3=37.8597;

%Grijanje
v1=ss2-ss1;
x1=(v1*0.63)+ss1;
%tag=84.725*exp(0.0001*x1) + -151.54*exp(-0.01*x1);
tag= (-335.42*x1^5 + 37417*x1^4 + 1.4081e+05 *x1^3 + 11520 *x1^2 + 529.53*x1 + 19.441) / (x1^5 + -413.6*x1^4 + 35877*x1^3 + -4.6681e+05*x1^2 + -33682*x1 + -1475.8);
tauG=tag-108;
s = tf('s');
Kg = v1 / 220;          % make sure v1 is defined beforehand
Gh = tf([Kg], [tauG, 1]); % transfer function

tn2 = linspace(0,664 ,664*2);  % time vector
[y2, t_out2] = step(Gh * 220, tn2); % scale step input by 220, get response

plot(t_out2, y2);
t_shifted = t_out2 + 108;            % Shift time right by 135s
y_shifted = y2 + ss1;            % Shift output up by 46.8771



%Hlađenje
v2=ss3-ss2;
x2=(v2*0.63)+ss2;
tah= 1207.6*exp(-0.0045*x2) + 66655*exp(-0.1311*x2);
tauH=tah-807.5;
Kh = v2 / 220;          % make sure v1 is defined beforehand
Gh = tf([Kh], [tauH, 1]); % transfer function

tn2 = linspace(0,722 ,722*2);  % time vector
[y2, t_out2] = step(Gh * 220, tn2); % scale step input by 220, get response

plot(t_out2, y2);
t_shifted2 = t_out2 + 807.5;            % Shift time right by 135s
y_shifted2 = y2 + ss2;   

figure;
hold on;
grid on;
%plot(t,izlaz,'LineWidth',1.5);
%plot(t,Rn,'LineWidth',1.5);
plot(t,T,'LineWidth',1.5);
plot(t1,SS1,'LineWidth',1.5);
plot(t2,SS2,'LineWidth',1.5);
plot(t_shifted, y_shifted);
plot(t_shifted2, y_shifted2);

figure;
hold on;
grid on;
plot(out.out,'LineWidth',1.5);
xlabel("Vrijeme [s]");
ylabel("Temperatura [°C]");