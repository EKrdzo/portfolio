tG1=tG+1395;
t1=0:0.5:120;
y1=SSSH*ones(1,241);
t2=0:0.5:135;
y2=SSSG*ones(1,271);

s = tf('s');

GH = tf([KH], [tauH, 1]);
tnH = linspace(0, 1275, 1275*2);  % time vector
[yH, t_outH] = step(GH * 220, tnH); % scale step input by 220, get response

GG = tf([KG], [tauG, 1]);
tnG = linspace(0, 672, 672*2);  % time vector
[yG, t_outG] = step(GG * 220, tnG); % scale step input by 220, get response


figure;
hold on;
grid on;
xlabel("Vrijeme [s]");
ylabel("Temperatura [°C]");
plot(tH,TH,'b','LineWidth',1.5);
plot(tG1,TG,'b','LineWidth',1.5);
plot(t1,y1,'r','LineWidth',1);
plot((t2+1395),y2,'r','LineWidth',1);
plot((t_outH+120),(yH+SSSH),'r','LineWidth',1);
plot((t_outG+135+1395),(yG+SSSG),'y','LineWidth',1);
plot(tH,(220.*uH),'g','LineWidth',1.5);
plot((tG+1395),(220.*uG),'g','LineWidth',1.5);
